<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>

     <?php $__env->slot('header', null, []); ?> Quiz Düzenleme <?php $__env->endSlot(); ?>

    <div class="card">
        <div class="card-body">
            <form action="<?php echo e(route('quizzes.update',$quiz->id)); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="form-group">
                    <label>Quiz Başlığı</label>
                    <input type="text" name="title" class="form-control" value="<?php echo e($quiz->title); ?>">
                </div>
                <div class="form-group">
                    <label>Quiz Açıklaması</label>
                   <textarea name="description" class="form-control" rows="4" ><?php echo e($quiz->description); ?></textarea>
                </div>
                <div class="form-group">
                    <label>Quiz Durum</label>
                    <select name="status" class="form-control">
                        <option value="publish">Aktif</option>
                        <option value="passive">Pasif</option>
                        <option value="draft">Beklemede</option>
                    </select>
                </div>
                <div class="form-group">
                    <input id="isFinished" <?php if($quiz->finished_at): ?> checked <?php endif; ?> type="checkbox">
                    <label>Bitiş Tarihi Ekle</label>
                </div>
                <div <?php if(!$quiz->finished_at): ?> style="display: none" <?php endif; ?> id="finishedInput" class="form-group">
                    <label>Quiz Bitiş Tarihi</label>
                    <input type="datetime-local" name="finished_at" class="form-control" <?php if($quiz->finished_at): ?> value="<?php echo e(date('Y-m-d\TH:i', strtotime($quiz->finished_at))); ?>" <?php endif; ?>>
                </div>
                <div class="form-group">
                    <button type="submit" class="btn btn-success btn-sm btn-block" >Kaydet</button>
                </div>
            </form>
        </div>
    </div>
     <?php $__env->slot('js', null, []); ?> 
        <script>
            $('#isFinished').change(function(){
                if($('#isFinished').is(':checked')){
                    $('#finishedInput').show();
                }else{
                    $('#finishedInput').hide();
                }
            })
        </script>

     <?php $__env->endSlot(); ?>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/Admin/Quiz/edit.blade.php ENDPATH**/ ?>