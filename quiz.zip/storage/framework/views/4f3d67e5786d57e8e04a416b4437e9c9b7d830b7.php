<!DOCTYPE html>
<html lang="en-US">
<head>
    <title> <?php echo $__env->yieldContent('title'); ?> </title>
    <meta name="author" content="Nile-Theme">
    <meta http-equiv="content-type" content="text/html; charset=utf-8">
    <meta name="keywords" content="<?php echo $__env->yieldContent('keywords'); ?>">
    <meta name="description" content="<?php echo $__env->yieldContent('description'); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <!-- google fonts -->
    <link href="https://fonts.googleapis.com/css?family=Open+Sans:400,600,800%7CPoppins:100,200,300i,300,400,700,400i,500%7CDancing+Script:700" rel="stylesheet">
    <!-- animate -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/animate.css" />
    <!-- owl Carousel assets -->
    <link href="<?php echo e(asset('assets')); ?>/css/owl.carousel.css" rel="stylesheet">
    <link href="<?php echo e(asset('assets')); ?>/css/owl.theme.css" rel="stylesheet">
    <script src="https://cdn.ckeditor.com/4.17.1/standard/ckeditor.js"></script>
    <!-- bootstrap -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css">
    <!-- hover anmation -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/hover-min.css">
    <!-- flag icon -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/flag-icon.min.css">
    <!-- main style -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/style.css">
    <!-- colors -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/colors/main.css">
    <!-- elegant icon -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/elegant_icon.css">
    <!-- Font Awesome -->
    <link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/fontawesome-all.min.css">
    <?php echo $__env->yieldContent('css'); ?>

</head>

<body>
<?php echo $__env->make('home._header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>



<?php $__env->startSection('content'); ?>

<?php echo $__env->yieldSection(); ?>

<?php echo $__env->make('home._footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>
<?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/layouts/home.blade.php ENDPATH**/ ?>