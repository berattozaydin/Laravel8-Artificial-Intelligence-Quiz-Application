<?php
    $setting = \App\Http\Controllers\Admin\SettingController::getsetting()
?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Sorular <?php $__env->endSlot(); ?>
  <div class="card">
      <div class="card-body">
          <h5 class="card-title">
              <a href="<?php echo e(route('sorulars.create',[$sorular_create?->id])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i>Soru Oluştur</a></h5>
          <table class="table">

              <tr>
                  <th scope="col" style="background-color:#0dcaf0">Soru</th>
                  <th scope="col" style="background-color:#0dcaf0">Resim</th>
                  <th scope="col" style="background-color:#0dcaf0">A Şıkkı</th>
                  <th scope="col" style="background-color:#0dcaf0">B Şıkkı</th>
                  <th scope="col" style="background-color:#0dcaf0">C Şıkkı</th>
                  <th scope="col" style="background-color:#0dcaf0">D Şıkkı</th>
                  <th scope="col" style="background-color:#0dcaf0">Doğru Şık</th>
                  <th scope="col" style="background-color:#0dcaf0">Ayarlar</th>
              </tr>

              <tbody>
              <?php $__currentLoopData = $sorular_create->sorulars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sorular): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                      <td><?php echo $sorular->question; ?></td>
                      <?php if($sorular->image_question): ?>
                          <td><img src="<?php echo e(asset($sorular->image_question)); ?>" style="height: 50px;width: 50px;"></td>
                      <?php endif; ?>
                      <?php if($sorular->image_question==null): ?>
                      <td>Resim Yok</td>
                      <?php endif; ?>
                      <td><?php echo $sorular->a; ?> </td>
                      <td><?php echo $sorular->b; ?> </td>
                      <td><?php echo $sorular->c; ?></td>
                      <td><?php echo $sorular->d; ?></td>
                      <td><?php echo $sorular->correctanswer; ?></td>

                      <td>

                          <a href="<?php echo e(route('sorulars.edit',[$sorular->quiz_id,$sorular->id])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i>Düzenle</a>
                          <a href="<?php echo e(route('sorulars.destroy',[$sorular->quiz_id,$sorular->id])); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i>Sil</a>
                      </td>
                  </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/admin/sorular/list.blade.php ENDPATH**/ ?>