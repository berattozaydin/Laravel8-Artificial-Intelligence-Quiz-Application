<?php $__env->startSection('content'); ?>
    <div class="banner padding-tb-20px">
        <div class="container">

            <div class="padding-tb-120px z-index-2 position-relative">
                <div class="text-center">
                    <h1 class="text-white pull-l icon-large font-weight-500 margin-bottom-40px">Karabük Üniversitesi Quiz Sitesi</h1>

                </div>

            </div>
        </div>
        <!-- //container  -->
        <video class="background-grey-3" autoplay loop id="video-background" muted plays-inline><source src="#video-url" type="video/mp4"></video>

    </div>
    <div class="background-light-grey">
        <h3 style="text-align: center;">Var Olan Quizler</h3>
        <div class="container padding-top-100px">
            <div class="row">
                                <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-xl-2 col-lg-3 col-md-4 col-6 sm-mb-25px">
                        <a href="<?php echo e(route('quiz.detay',$rs->slug)); ?>" class="d-block box-shadow background-main-color text-white hvr-float">
                            <div class="thum" title="<?php echo e($rs->description); ?>"><h6 class="text-center padding-15px"><?php echo e($rs->title); ?><br>
                                    Bitiş Tarihi : <?php echo e($rs->finished_at); ?></h6>
                            </div>
                        </a>
                    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/home/index.blade.php ENDPATH**/ ?>