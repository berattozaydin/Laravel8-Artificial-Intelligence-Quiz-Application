<link rel="shortcut icon" type="image/x-icon" href="<?php echo e(asset('assets')); ?>/img/favicon.ico">
<!-- Google Fonts
    ============================================ -->
<link href="https://fonts.googleapis.com/css?family=Roboto:100,300,400,700,900" rel="stylesheet">
<!-- Bootstrap CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/bootstrap.min.css">
<!-- Bootstrap CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/font-awesome.min.css">
<!-- nalika Icon CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/nalika-icon.css">
<!-- owl.carousel CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.carousel.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.theme.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/owl.transitions.css">
<!-- animate CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/animate.css">
<!-- normalize CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/normalize.css">
<!-- meanmenu icon CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/meanmenu.min.css">
<!-- main CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/main.css">
<!-- morrisjs CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/morrisjs/morris.css">
<!-- mCustomScrollbar CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/scrollbar/jquery.mCustomScrollbar.min.css">
<!-- metisMenu CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/metisMenu/metisMenu.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/metisMenu/metisMenu-vertical.css">
<!-- calendar CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/calendar/fullcalendar.min.css">
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/calendar/fullcalendar.print.min.css">
<!-- style CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/style.css">
<!-- responsive CSS
    ============================================ -->
<link rel="stylesheet" href="<?php echo e(asset('assets')); ?>/css/responsive.css">
<!-- modernizr JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/vendor/modernizr-2.8.3.min.js"></script>


<!-- jquery
		============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/vendor/jquery-1.12.4.min.js"></script>
<!-- bootstrap JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/bootstrap.min.js"></script>
<!-- wow JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/wow.min.js"></script>
<!-- price-slider JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/jquery-price-slider.js"></script>
<!-- meanmenu JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/jquery.meanmenu.js"></script>
<!-- owl.carousel JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/owl.carousel.min.js"></script>
<!-- sticky JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/jquery.sticky.js"></script>
<!-- scrollUp JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/jquery.scrollUp.min.js"></script>
<!-- mCustomScrollbar JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/scrollbar/jquery.mCustomScrollbar.concat.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/scrollbar/mCustomScrollbar-active.js"></script>
<!-- metisMenu JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/metisMenu/metisMenu.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/metisMenu/metisMenu-active.js"></script>
<!-- sparkline JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/sparkline/jquery.sparkline.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/sparkline/jquery.charts-sparkline.js"></script>
<!-- calendar JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/calendar/moment.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/calendar/fullcalendar.min.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/calendar/fullcalendar-active.js"></script>
<!-- float JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/flot/jquery.flot.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/flot/jquery.flot.resize.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/flot/curvedLines.js"></script>
<script src="<?php echo e(asset('assets')); ?>/js/flot/flot-active.js"></script>
<!-- plugins JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/plugins.js"></script>
<!-- main JS
    ============================================ -->
<script src="<?php echo e(asset('assets')); ?>/js/main.js"></script>
<?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/Admin/Quiz/scripts.blade.php ENDPATH**/ ?>