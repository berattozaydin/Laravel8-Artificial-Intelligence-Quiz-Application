<?php
    $setting = \App\Http\Controllers\Admin\SettingController::getsetting()
?>
<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, [] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\AppLayout::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> Admin Panel <?php $__env->endSlot(); ?>
  <div class="card">
      <div class="card-body">
          <h5 class="card-title"><a href="<?php echo e(route('quizzes.create')); ?>" class="btn btn-sm btn-primary"><i class="fa fa-plus"></i>Quiz Oluştur</a></h5>
          <table class="table">
              <thead class="thead-dark">
              <tr>
                  <th scope="col" style="background-color:#0dcaf0"> Quiz</th>
                  <th scope="col" style="background-color:#0dcaf0">Durum</th>
                  <th scope="col" style="background-color:#0dcaf0">Bitiş Tarihi</th>
                  <th scope="col" style="background-color:#0dcaf0">Quize Ait Soru Sayısı</th>
                  <th scope="col" style="background-color:#0dcaf0"> İşlemler</th>
              </tr>
              </thead>
              <tbody>
              <?php $__currentLoopData = $quizzes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $quiz): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                  <th><?php echo e($quiz->title); ?></th>
                  <td>
                  <?php if($quiz->status=='publish'): ?>
                      Aktif
                      <?php elseif($quiz->status=='passive'): ?>
                      Pasif
                      <?php else: ?>
                      Beklemede
                      <?php endif; ?>
                  </td>
                  <td><?php echo e($quiz->finished_at); ?></td>
                  <td><?php echo e(count($quiz->sorulars)); ?></td>
                  <td>
                      <a href="<?php echo e(route('quizsonuc',$quiz->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-info-circle"></i>Sonuçlar</a>
                      <a href="<?php echo e(route('quizzes.edit',$quiz->id)); ?>" class="btn btn-sm btn-primary"><i class="fa fa-edit"></i>Düzenle</a>
                      <a href="<?php echo e(route('sorulars.index',$quiz->id)); ?>" class="btn btn-sm btn-Question"><i class="fa fa-edit"></i>Sorular</a>
                      <a href="<?php echo e(route('quizzes.destroy',$quiz->id)); ?>" class="btn btn-sm btn-danger"><i class="fa fa-times"></i>Sil</a>
                  </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </tbody>
          </table>
          <?php echo e($quizzes->links()); ?>

      </div>
  </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/Admin/Quiz/list.blade.php ENDPATH**/ ?>