<?php $__env->startSection('content'); ?>
    <div id="page-title" class="padding-tb-30px gradient-white">
        <div class="container text-left">
            <h1 class="font-weight-300"><?php echo e($sinav->title); ?></h1>
        </div>
    </div>


    <div class="container">
        <div class="row">

            <div class="col-lg-8">
                <div class="margin-bottom-40px card border-0 box-shadow">
                    <div class="padding-lr-30px padding-tb-20px">
                        <hr>
                        <h3>Sınav Soruları</h3>
                        <div class="card-body">
                            <div class="card-text">
                                <form method="POST" action="<?php echo e(route('quiz.sonuc',$sinav->slug)); ?>">
                                    <?php echo csrf_field(); ?>

                        <?php $__currentLoopData = $sinav->sorulars; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $soru): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <strong>Soru <?php echo e($loop->iteration); ?>: </strong> <h5 class="mt-2"><?php echo $soru->question; ?></h5>
                                    <?php if($soru->image_question): ?>
                                        <img src="<?php echo e(asset($soru->image_question)); ?>" alt="<?php echo e($soru->question); ?>" class="img-responsive" style="width: 250px;height: 200px;">
                                    <?php endif; ?>

                        <div class="form-check mt-3">
                            <input class="form-check-input" type="radio" name="<?php echo e($soru->id); ?>" id="quiz<?php echo e($soru->id); ?>1" value="a" required>
                            <label class="form-check-label" for="quiz<?php echo e($soru->id); ?>1">
                              A)  <?php echo $soru->a; ?>

                            </label>
                        </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="<?php echo e($soru->id); ?>" id="quiz<?php echo e($soru->id); ?>2" value="b" required>
                                        <label class="form-check-label" for="quiz<?php echo e($soru->id); ?>2">
                                            B)  <?php echo $soru->b; ?>

                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="<?php echo e($soru->id); ?>" id="quiz<?php echo e($soru->id); ?>3" value="c" required>
                                        <label class="form-check-label" for="quiz<?php echo e($soru->id); ?>3">
                                            C) <?php echo $soru->c; ?>

                                        </label>
                                    </div>
                                    <div class="form-check">
                                        <input class="form-check-input" type="radio" name="<?php echo e($soru->id); ?>" id="quiz<?php echo e($soru->id); ?>4" value="d" required>
                                        <label class="form-check-label" for="quiz<?php echo e($soru->id); ?>4">
                                            D)  <?php echo $soru->d; ?>

                                        </label>
                                    </div>
                                    <hr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <button class="btn btn-primary btn-sm btn-block" type="submit">Sınavı Bitir</button>
                                </form>
                    </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Berat\Desktop\quiz\quiz\resources\views/home/sinav.blade.php ENDPATH**/ ?>