<x-app-layout>
    <x-slot name="header">
Anasayfa
    </x-slot>
</x-app-layout>
