require('./bootstrap');
require('jquery')
import Alpine from 'alpinejs';
import $ from 'jquery';
window.Alpine = Alpine;
window.jQuery=$;
window.$=$;
Alpine.start();
